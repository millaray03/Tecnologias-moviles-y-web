package com.example.menuprincipal1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ClienteAdapter extends RecyclerView.Adapter<ClienteAdapter.ClienteViewHolder> {

    private List<Cliente> listaClientes;

    public ClienteAdapter(List<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    @NonNull
    @Override
    public ClienteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cliente, parent, false);
        return new ClienteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ClienteViewHolder holder, int position) {
        Cliente cliente = listaClientes.get(position);
        holder.txtNombre.setText(cliente.getNombre());
        holder.txtRut.setText("RUT: " + cliente.getRut());
        holder.txtTelefono.setText("📞 " + cliente.getTelefono());
        holder.txtEmail.setText("✉️ " + cliente.getEmail());
    }

    @Override
    public int getItemCount() {
        return listaClientes.size();
    }

    // 🔹 Método para actualizar la lista (usado en onResume)
    public void actualizarLista(List<Cliente> nuevaLista) {
        this.listaClientes = nuevaLista;
        notifyDataSetChanged();
    }

    public static class ClienteViewHolder extends RecyclerView.ViewHolder {
        TextView txtNombre,txtRut,  txtTelefono, txtEmail;

        public ClienteViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNombre = itemView.findViewById(R.id.txtNombreCliente);
            txtRut = itemView.findViewById(R.id.textRut);
            txtTelefono = itemView.findViewById(R.id.txtTelefonoCliente);
            txtEmail = itemView.findViewById(R.id.txtEmailCliente);
        }
    }
}

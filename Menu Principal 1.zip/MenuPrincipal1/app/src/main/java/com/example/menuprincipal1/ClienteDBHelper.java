package com.example.menuprincipal1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ClienteDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "clientes.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "clientes";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NOMBRE = "nombre";

    public static final String COLUMN_RUT = "rut";

    public static final String COLUMN_TELEFONO = "telefono";
    public static final String COLUMN_EMAIL = "email";

    public ClienteDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NOMBRE + " TEXT, " +
                COLUMN_RUT + " TEXT, " +
                COLUMN_TELEFONO + " TEXT, " +
                COLUMN_EMAIL + " TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insertar cliente (void)
    public void insertarCliente(String nombre, String rut, String telefono, String email) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, nombre);
        values.put(COLUMN_RUT, rut);
        values.put(COLUMN_TELEFONO, telefono);
        values.put(COLUMN_EMAIL, email);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Obtener todos los clientes como List<Cliente>
    public List<Cliente> obtenerTodosLosClientes() {
        List<Cliente> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " ORDER BY " + COLUMN_NOMBRE + " COLLATE NOCASE", null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                    String nombre = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOMBRE));
                    String rut = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_RUT));
                    String telefono = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TELEFONO));
                    String email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL));
                    lista.add(new Cliente(id, nombre, rut, telefono, email));
                } while (cursor.moveToNext());
            }
            cursor.close();
        }
        db.close();
        return lista;
    }

    // Eliminar cliente por id
    public void eliminarCliente(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
}


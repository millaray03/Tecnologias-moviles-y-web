package com.example.menuprincipal1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NuevoClienteActivity extends AppCompatActivity {

    private EditText editNombre, editRut, editTelefono, editEmail;
    private Button btnGuardar;
    private ClienteDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_cliente);

        editNombre = findViewById(R.id.editNombre);
        editRut = findViewById(R.id.editRut);
        editTelefono = findViewById(R.id.editTelefono);
        editEmail = findViewById(R.id.editEmail);
        btnGuardar = findViewById(R.id.btnGuardar);

        dbHelper = new ClienteDBHelper(this);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = editNombre.getText().toString().trim();
                String rut = editRut.getText().toString().trim();
                String telefono = editTelefono.getText().toString().trim();
                String email = editEmail.getText().toString().trim();

                if (nombre.isEmpty() ||rut.isEmpty() || telefono.isEmpty() || email.isEmpty()) {
                    Toast.makeText(NuevoClienteActivity.this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    dbHelper.insertarCliente(nombre, rut, telefono, email);
                    Toast.makeText(NuevoClienteActivity.this, "Cliente guardado correctamente", Toast.LENGTH_SHORT).show();
                    finish(); // vuelve a la pantalla anterior (GestiondeClientesActivity)
                }
            }
        });
    }
}


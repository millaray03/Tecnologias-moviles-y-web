package com.example.menuprincipal1;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddOrderActivity extends AppCompatActivity {

    private TextInputEditText etClientName, etVehicle, etLicensePlate, etDate, etDescription, etTotal;
    private Spinner spinnerStatus;
    private Button btnSave, btnCancel;
    private OrderDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_order);

        initializeViews();
        setupSpinner();
        setupClickListeners();

        // Establecer fecha actual por defecto
        setCurrentDate();
    }

    private void initializeViews() {
        etClientName = findViewById(R.id.etClientName);
        etVehicle = findViewById(R.id.etVehicle);
        etLicensePlate = findViewById(R.id.etLicensePlate);
        etDate = findViewById(R.id.etDate);
        etDescription = findViewById(R.id.etDescription);
        etTotal = findViewById(R.id.etTotal);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        dbHelper = new OrderDBHelper(this);
    }

    private void setupSpinner() {
        // Estados posibles para una orden
        String[] statusOptions = {"Pendiente", "En Proceso", "Completada", "Cancelada"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statusOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);
    }

    private void setupClickListeners() {
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveOrder();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Cierra la actividad sin guardar
            }
        });

        // Establecer fecha actual al hacer clic en el campo de fecha
        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setCurrentDate();
            }
        });
    }

    private void setCurrentDate() {
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        etDate.setText(currentDate);
    }

    private void saveOrder() {
        // Validar campos obligatorios
        if (!validateFields()) {
            return;
        }

        try {
            // Crear nuevo objeto Order
            Order newOrder = new Order(
                    etClientName.getText().toString().trim(),
                    etVehicle.getText().toString().trim(),
                    etLicensePlate.getText().toString().trim().toUpperCase(),
                    etDate.getText().toString().trim(),
                    spinnerStatus.getSelectedItem().toString(),
                    etDescription.getText().toString().trim(),
                    Double.parseDouble(etTotal.getText().toString())
            );

            // Guardar en la base de datos
            dbHelper.addOrder(newOrder);

            Toast.makeText(this, "Orden guardada exitosamente", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Error: El total debe ser un número válido", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar la orden: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean validateFields() {
        if (etClientName.getText().toString().trim().isEmpty()) {
            etClientName.setError("El nombre del cliente es obligatorio");
            return false;
        }

        if (etVehicle.getText().toString().trim().isEmpty()) {
            etVehicle.setError("El vehículo es obligatorio");
            return false;
        }

        if (etLicensePlate.getText().toString().trim().isEmpty()) {
            etLicensePlate.setError("La placa es obligatoria");
            return false;
        }

        if (etDate.getText().toString().trim().isEmpty()) {
            etDate.setError("La fecha es obligatoria");
            return false;
        }

        if (etDescription.getText().toString().trim().isEmpty()) {
            etDescription.setError("La descripción es obligatoria");
            return false;
        }

        if (etTotal.getText().toString().trim().isEmpty()) {
            etTotal.setError("El total es obligatorio");
            return false;
        }

        try {
            Double.parseDouble(etTotal.getText().toString());
        } catch (NumberFormatException e) {
            etTotal.setError("El total debe ser un número válido");
            return false;
        }

        return true;
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}

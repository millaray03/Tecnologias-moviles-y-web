package com.example.menuprincipal1;

// OrderDBHelper.java
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class OrderDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "automotriz.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_ORDERS = "orders";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_CLIENT_NAME = "client_name";
    private static final String COLUMN_VEHICLE = "vehicle";
    private static final String COLUMN_LICENSE_PLATE = "license_plate";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_STATUS = "status";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_TOTAL = "total";

    public OrderDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_ORDERS_TABLE = "CREATE TABLE " + TABLE_ORDERS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_CLIENT_NAME + " TEXT,"
                + COLUMN_VEHICLE + " TEXT,"
                + COLUMN_LICENSE_PLATE + " TEXT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_STATUS + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_TOTAL + " REAL" + ")";
        db.execSQL(CREATE_ORDERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        onCreate(db);
    }

    // CREATE
    public void addOrder(Order order) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CLIENT_NAME, order.getClientName());
        values.put(COLUMN_VEHICLE, order.getVehicle());
        values.put(COLUMN_LICENSE_PLATE, order.getLicensePlate());
        values.put(COLUMN_DATE, order.getDate());
        values.put(COLUMN_STATUS, order.getStatus());
        values.put(COLUMN_DESCRIPTION, order.getDescription());
        values.put(COLUMN_TOTAL, order.getTotal());

        db.insert(TABLE_ORDERS, null, values);
        db.close();
    }

    // READ (All)
    public List<Order> getAllOrders() {
        List<Order> orderList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_ORDERS + " ORDER BY " + COLUMN_DATE + " DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Order order = new Order();
                order.setId(cursor.getInt(0));
                order.setClientName(cursor.getString(1));
                order.setVehicle(cursor.getString(2));
                order.setLicensePlate(cursor.getString(3));
                order.setDate(cursor.getString(4));
                order.setStatus(cursor.getString(5));
                order.setDescription(cursor.getString(6));
                order.setTotal(cursor.getDouble(7));

                orderList.add(order);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return orderList;
    }

    // UPDATE
    public void updateOrder(Order order) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CLIENT_NAME, order.getClientName());
        values.put(COLUMN_VEHICLE, order.getVehicle());
        values.put(COLUMN_LICENSE_PLATE, order.getLicensePlate());
        values.put(COLUMN_DATE, order.getDate());
        values.put(COLUMN_STATUS, order.getStatus());
        values.put(COLUMN_DESCRIPTION, order.getDescription());
        values.put(COLUMN_TOTAL, order.getTotal());

        db.update(TABLE_ORDERS, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(order.getId())});
        db.close();
    }

    // DELETE
    public void deleteOrder(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ORDERS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}

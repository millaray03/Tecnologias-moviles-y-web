package com.example.menuprincipal1;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class BuscarClientesActivity extends AppCompatActivity {

    private Spinner spinnerCriterio, spinnerOrden;
    private LinearLayout layoutCampoBusqueda;
    private TextView tvLabelBusqueda, tvResultados;
    private EditText etBusqueda;
    private LinearLayout layoutResultados;
    private Button btnBuscar, btnLimpiar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_clientes);

        // Inicializar vistas
        spinnerCriterio = findViewById(R.id.spinnerCriterio);
        spinnerOrden = findViewById(R.id.spinnerOrden);
        layoutCampoBusqueda = findViewById(R.id.layoutCampoBusqueda);
        tvLabelBusqueda = findViewById(R.id.tvLabelBusqueda);
        etBusqueda = findViewById(R.id.etBusqueda);
        tvResultados = findViewById(R.id.tvResultados);
        layoutResultados = findViewById(R.id.layoutResultados);
        btnBuscar = findViewById(R.id.btnBuscar);
        btnLimpiar = findViewById(R.id.btnLimpiar);

        // Datos hardcodeados para Spinners
        ArrayList<String> criteriosBusqueda = new ArrayList<>();
        criteriosBusqueda.add("Seleccione criterio");
        criteriosBusqueda.add("Por Nombre");
        criteriosBusqueda.add("Por RUN");
        criteriosBusqueda.add("Por Vehículo");
        criteriosBusqueda.add("Por Ciudad");

        ArrayList<String> ordenes = new ArrayList<>();
        ordenes.add("Nombre A-Z");
        ordenes.add("Nombre Z-A");
        ordenes.add("RUN Ascendente");
        ordenes.add("RUN Descendente");

        // Configurar adaptadores
        ArrayAdapter<String> adapterCriterio = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, criteriosBusqueda);
        adapterCriterio.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCriterio.setAdapter(adapterCriterio);

        ArrayAdapter<String> adapterOrden = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, ordenes);
        adapterOrden.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOrden.setAdapter(adapterOrden);

        // Listener para cambio de criterio
        spinnerCriterio.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String criterioSeleccionado = parent.getItemAtPosition(position).toString();
                actualizarCampoBusqueda(criterioSeleccionado);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Listener para botón Buscar
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarBusqueda();
            }
        });

        // Listener para botón Limpiar
        btnLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limpiarBusqueda();
            }
        });
    }

    private void actualizarCampoBusqueda(String criterio) {
        if (criterio.equals("Seleccione criterio")) {
            layoutCampoBusqueda.setVisibility(View.GONE);
            return;
        }

        layoutCampoBusqueda.setVisibility(View.VISIBLE);

        switch (criterio) {
            case "Por Nombre":
                tvLabelBusqueda.setText("Buscar por Nombre");
                etBusqueda.setHint("Ej: Juan, María...");
                break;
            case "Por RUN":
                tvLabelBusqueda.setText("Buscar por RUN");
                etBusqueda.setHint("Ej: 12.345.678-9");
                break;
            case "Por Vehículo":
                tvLabelBusqueda.setText("Buscar por Vehículo");
                etBusqueda.setHint("Ej: Toyota, ABC123...");
                break;
            case "Por Ciudad":
                tvLabelBusqueda.setText("Buscar por Ciudad");
                etBusqueda.setHint("Ej: Santiago, Valparaíso...");
                break;
        }
    }

    private void realizarBusqueda() {
        String criterio = spinnerCriterio.getSelectedItem().toString();
        String textoBusqueda = etBusqueda.getText().toString().trim();
        String orden = spinnerOrden.getSelectedItem().toString();

        if (criterio.equals("Seleccione criterio")) {
            Toast.makeText(this, "Seleccione un criterio de búsqueda", Toast.LENGTH_SHORT).show();
            return;
        }

        if (textoBusqueda.isEmpty()) {
            Toast.makeText(this, "Ingrese texto para buscar", Toast.LENGTH_SHORT).show();
            return;
        }

        // Simular búsqueda
        String mensaje = "Buscando '" + textoBusqueda + "' por " + criterio + " - Orden: " + orden;
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();

        // Mostrar resultados simulados
        mostrarResultadosSimulados(criterio, textoBusqueda);
    }

    private void mostrarResultadosSimulados(String criterio, String busqueda) {
        // Limpiar resultados anteriores
        layoutResultados.removeAllViews();

        // Simular resultados según el criterio
        ArrayList<String> resultados = new ArrayList<>();

        switch (criterio) {
            case "Por Nombre":
                if (busqueda.toLowerCase().contains("juan") || busqueda.toLowerCase().contains("mar")) {
                    resultados.add("Juan Pérez - RUN: 12.345.678-9");
                    resultados.add("María González - RUN: 98.765.432-1");
                }
                break;
            case "Por RUN":
                if (busqueda.contains("123") || busqueda.contains("987")) {
                    resultados.add("Juan Pérez - RUN: 12.345.678-9");
                    resultados.add("María González - RUN: 98.765.432-1");
                }
                break;
            case "Por Vehículo":
                if (busqueda.toLowerCase().contains("toyota") || busqueda.toLowerCase().contains("abc")) {
                    resultados.add("Juan Pérez - Toyota Corolla ABC123");
                    resultados.add("Carlos López - Toyota Hilux DEF456");
                }
                break;
            case "Por Ciudad":
                if (busqueda.toLowerCase().contains("santiago")) {
                    resultados.add("Juan Pérez - Santiago Centro");
                    resultados.add("Ana Silva - Santiago Norte");
                }
                break;
        }

        // Mostrar resultados
        if (resultados.isEmpty()) {
            tvResultados.setText("No se encontraron resultados");
        } else {
            tvResultados.setText("Resultados (" + resultados.size() + " encontrados)");

            for (String resultado : resultados) {
                agregarResultadoALista(resultado);
            }
        }
    }

    private void agregarResultadoALista(String textoResultado) {
        LinearLayout cardResultado = new LinearLayout(this);
        cardResultado.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        cardResultado.setOrientation(LinearLayout.VERTICAL);
        cardResultado.setBackgroundResource(R.drawable.card_background);
        cardResultado.setPadding(16, 16, 16, 16);

        LinearLayout.LayoutParams marginParams = (LinearLayout.LayoutParams) cardResultado.getLayoutParams();
        marginParams.bottomMargin = 8;
        cardResultado.setLayoutParams(marginParams);

        TextView tvNombre = new TextView(this);
        tvNombre.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        tvNombre.setText(textoResultado.split(" - ")[0]);
        tvNombre.setTextSize(14);
        tvNombre.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvDetalle = new TextView(this);
        tvDetalle.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        tvDetalle.setText(textoResultado.split(" - ")[1]);
        tvDetalle.setTextSize(12);

        cardResultado.addView(tvNombre);
        cardResultado.addView(tvDetalle);
        layoutResultados.addView(cardResultado);
    }

    private void limpiarBusqueda() {
        spinnerCriterio.setSelection(0);
        spinnerOrden.setSelection(0);
        etBusqueda.setText("");
        layoutCampoBusqueda.setVisibility(View.GONE);
        layoutResultados.removeAllViews();
        tvResultados.setText("Resultados (0 encontrados)");
        Toast.makeText(this, "Búsqueda limpiada", Toast.LENGTH_SHORT).show();
    }
}
package com.example.menuprincipal1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class GestiondeClientesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ClienteAdapter adapter;
    private ClienteDBHelper dbHelper;
    private Button btnNuevoCliente, btnBuscarClientes, btnVolverMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_clientes);

        // Referencias a vistas (asegúrate que los IDs coincidan con el XML)
        recyclerView = findViewById(R.id.recyclerClientes);
        btnNuevoCliente = findViewById(R.id.btnNuevoCliente);
        btnBuscarClientes = findViewById(R.id.btnBuscarClientes);
        btnVolverMenu = findViewById(R.id.btnVolverMenu);

        dbHelper = new ClienteDBHelper(this);

        // Configurar RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Cliente> lista = dbHelper.obtenerTodosLosClientes();
        adapter = new ClienteAdapter(lista);
        recyclerView.setAdapter(adapter);

        // Botones
        btnNuevoCliente.setOnClickListener(v -> {
            Intent i = new Intent(GestiondeClientesActivity.this, NuevoClienteActivity.class);
            startActivity(i);
        });

        btnBuscarClientes.setOnClickListener(v -> {
            Toast.makeText(this, "Búsqueda avanzada aún no implementada", Toast.LENGTH_SHORT).show();
        });

        btnVolverMenu.setOnClickListener(v -> {
            // Cambia MainActivity.class si tu Activity principal tiene otro nombre
            Intent i = new Intent(GestiondeClientesActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refrescar lista al volver (evita NullPointer: comprobar adapter no nulo)
        if (adapter != null) {
            List<Cliente> nueva = dbHelper.obtenerTodosLosClientes();
            adapter.actualizarLista(nueva);
        }
    }
}

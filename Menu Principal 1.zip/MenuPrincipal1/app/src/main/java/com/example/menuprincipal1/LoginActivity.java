package com.example.menuprincipal1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    TextInputEditText etUsuario, etContrasena;
    MaterialButton btnIngresar;
    TextView tvForgotPassword;

    // Usuario y contraseña válidos (puedes cambiarlos)
    final String USUARIO_VALIDO = "admin";
    final String CONTRASENA_VALIDA = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        // Inicializar vistas - usa los mismos IDs que en el XML
        etUsuario = findViewById(R.id.etUsuario);
        etContrasena = findViewById(R.id.etContrasena);
        btnIngresar = findViewById(R.id.btnIngresar);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        // Listener para el botón de ingresar
        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUsuario();
            }
        });

        // Listener para "Olvidé mi contraseña"
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoRecuperacion();
            }
        });

        // Opcional: Permitir login al presionar "Enter" en la contraseña
        etContrasena.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginUsuario();
                    return true;
                }
                return false;
            }
        });
    }

    private void loginUsuario() {
        String usuario = etUsuario.getText().toString().trim();
        String contrasena = etContrasena.getText().toString().trim();

        // Validar campos vacíos
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            Toast.makeText(LoginActivity.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (usuario.equals(USUARIO_VALIDO) && contrasena.equals(CONTRASENA_VALIDA)) {
            // Si es correcto, abre el menú principal
            Intent intent = new Intent(LoginActivity.this, com.example.menuprincipal1.MainActivity.class);
            startActivity(intent);
            finish(); // Cierra el login para que no se pueda volver atrás
        } else {
            // Si está incorrecto, muestra mensaje
            Toast.makeText(LoginActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();

            // Opcional: Agregar animación de error
            etContrasena.setError("Contraseña incorrecta");
        }
    }

    private void mostrarDialogoRecuperacion() {
        // Crear un diálogo personalizado
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Recuperar Contraseña");

        // Layout para el diálogo
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText input = new EditText(this);
        input.setHint("Ingresa tu usuario");
        layout.addView(input);

        builder.setView(layout);

        builder.setPositiveButton("Enviar", (dialog, which) -> {
            String usuario = input.getText().toString().trim();
            if (usuario.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Por favor, ingresa un usuario", Toast.LENGTH_SHORT).show();
            } else if (usuario.equals(USUARIO_VALIDO)) {
                Toast.makeText(LoginActivity.this,
                        "Contraseña recuperada: " + CONTRASENA_VALIDA,
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(LoginActivity.this,
                        "Usuario no encontrado",
                        Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // Opcional: Limpiar error cuando el usuario empiece a escribir
    private void setupTextChangeListeners() {
        etUsuario.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                etUsuario.setError(null);
            }
        });

        etContrasena.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                etContrasena.setError(null);
            }
        });
    }

    // Clase auxiliar para simplificar TextWatcher
    private abstract class SimpleTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void afterTextChanged(Editable s) {}
    }
}
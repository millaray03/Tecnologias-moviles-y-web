package com.example.menuprincipal1;

// OrderAdapter.java
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {
    private List<Order> orderList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Order order);
        void onItemLongClick(Order order);
    }

    public OrderAdapter(List<Order> orderList, OnItemClickListener listener) {
        this.orderList = orderList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Order order = orderList.get(position);
        holder.bind(order, listener);
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public void updateOrders(List<Order> newOrders) {
        orderList.clear();
        orderList.addAll(newOrders);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvClientName, tvVehicle, tvLicensePlate, tvDate, tvStatus, tvTotal;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvClientName = itemView.findViewById(R.id.tvClientName);
            tvVehicle = itemView.findViewById(R.id.tvVehicle);
            tvLicensePlate = itemView.findViewById(R.id.tvLicensePlate);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvTotal = itemView.findViewById(R.id.tvTotal);
        }

        public void bind(final Order order, final OnItemClickListener listener) {
            tvClientName.setText(order.getClientName());
            tvVehicle.setText(order.getVehicle());
            tvLicensePlate.setText(order.getLicensePlate());
            tvDate.setText(order.getDate());
            tvStatus.setText(order.getStatus());
            tvTotal.setText(String.format("$%.2f", order.getTotal()));

            // Cambiar color según el estado
            switch (order.getStatus()) {
                case "Pendiente":
                    tvStatus.setBackgroundColor(0xFFFFEB3B); // Amarillo
                    break;
                case "En Proceso":
                    tvStatus.setBackgroundColor(0xFFFF9800); // Naranja
                    break;
                case "Completada":
                    tvStatus.setBackgroundColor(0xFF4CAF50); // Verde
                    break;
                case "Cancelada":
                    tvStatus.setBackgroundColor(0xFFF44336); // Rojo
                    break;
            }

            itemView.setOnClickListener(v -> listener.onItemClick(order));
            itemView.setOnLongClickListener(v -> {
                listener.onItemLongClick(order);
                return true;
            });
        }
    }
}

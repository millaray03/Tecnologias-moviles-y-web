package com.example.menuprincipal1;

// Order.java
public class Order {
    private int id;
    private String clientName;
    private String vehicle;
    private String licensePlate;
    private String date;
    private String status;
    private String description;
    private double total;

    public Order() {}

    public Order(String clientName, String vehicle, String licensePlate,
                 String date, String status, String description, double total) {
        this.clientName = clientName;
        this.vehicle = vehicle;
        this.licensePlate = licensePlate;
        this.date = date;
        this.status = status;
        this.description = description;
        this.total = total;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public String getVehicle() { return vehicle; }
    public void setVehicle(String vehicle) { this.vehicle = vehicle; }

    public String getLicensePlate() { return licensePlate; }
    public void setLicensePlate(String licensePlate) { this.licensePlate = licensePlate; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
}

package com.example.menuprincipal1;


// OrdersActivity.java
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;

public class OrdersActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private List<Order> orderList;
    private OrderDBHelper dbHelper;
    private FloatingActionButton fabAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        initializeViews();
        setupRecyclerView();
        loadOrders();

        fabAdd.setOnClickListener(v -> showAddOrderDialog());
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewOrders);
        fabAdd = findViewById(R.id.fabAdd);
        dbHelper = new OrderDBHelper(this);
        orderList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        adapter = new OrderAdapter(orderList, new OrderAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Order order) {
                showOrderDetails(order);
            }

            @Override
            public void onItemLongClick(Order order) {
                showDeleteDialog(order);
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadOrders(); // Refrescar datos al volver a la actividad
    }

    private void loadOrders() {
        List<Order> orders = dbHelper.getAllOrders();
        orderList.clear();
        orderList.addAll(orders);
        adapter.notifyDataSetChanged();

        // Mostrar mensaje si no hay órdenes
        if (orderList.isEmpty()) {
            Toast.makeText(this, "No hay órdenes de trabajo registradas", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            // Recargar la lista cuando se guarda una nueva orden
            loadOrders();
            Toast.makeText(this, "Nueva orden agregada", Toast.LENGTH_SHORT).show();
        }
    }
    private void showAddOrderDialog() {
        // Abrir la nueva actividad para crear órdenes
        Intent intent = new Intent(OrdersActivity.this, AddOrderActivity.class);
        startActivityForResult(intent, 1); // 1 es un código de request
    }

    private void showOrderDetails(Order order) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Detalles de Orden")
                .setMessage("Cliente: " + order.getClientName() + "\n" +
                        "Vehículo: " + order.getVehicle() + "\n" +
                        "Placa: " + order.getLicensePlate() + "\n" +
                        "Fecha: " + order.getDate() + "\n" +
                        "Estado: " + order.getStatus() + "\n" +
                        "Descripción: " + order.getDescription() + "\n" +
                        "Total: $" + order.getTotal())
                .setPositiveButton("Aceptar", null)
                .show();
    }

    private void showDeleteDialog(Order order) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar Orden")
                .setMessage("¿Estás seguro de eliminar esta orden?")
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    dbHelper.deleteOrder(order.getId());
                    loadOrders();
                    Toast.makeText(OrdersActivity.this, "Orden eliminada", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}

